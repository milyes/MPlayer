
# AITerminal Ubuntu Intelligence

Bienvenue sur **AITerminal Ubuntu Intelligence** !

## Fonctionnalités :
- Détecte toutes les commandes disponibles sous Ubuntu.
- Exécution par sélection ou saisie manuelle.
- Historique des exécutions.
- Gestion des commandes personnalisées.

## Utilisation :
- Cliquez sur **Run** pour lancer l'interface terminal dynamique.
- Suivez le menu affiché pour utiliser toutes les options disponibles.

Développé pour fonctionner sur Replit.
